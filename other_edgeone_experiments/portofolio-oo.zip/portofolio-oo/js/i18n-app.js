// i18n-app.js - Load content from JSON & switch language (EN / ID)
(function () {
    const LANG_KEY = 'portfolio_lang';
    const DEFAULT_LANG = 'en';

    function getLang() {
        return localStorage.getItem(LANG_KEY) || DEFAULT_LANG;
    }

    function setLang(lang) {
        localStorage.setItem(LANG_KEY, lang);
    }

    async function loadJSON(filename) {
        try {
            const res = await fetch('data/' + filename);
            if (!res.ok) throw new Error(res.statusText);
            return await res.json();
        } catch (e) {
            console.error('Error loading ' + filename, e);
            return null;
        }
    }

    function getDataByLang(data, lang) {
        if (!data) return null;
        if (data.en && data.id) return data[lang] || data.en;
        return data;
    }

    async function renderHero() {
        const raw = await loadJSON('hero.json');
        const hero = getDataByLang(raw, getLang());
        const container = document.getElementById('hero-content');
        if (!hero || !container) return;

        const buttons = hero.buttons.map(function (btn) {
            if (btn.type === 'primary') {
                return '<a href="' + btn.href + '" class="px-6 py-3 bg-primary text-white rounded-full hover:bg-primary-dark transition shadow-neumorph-btn">' + btn.text + '</a>';
            }
            return '<a href="' + btn.href + '" class="px-6 py-3 border-2 border-primary text-primary rounded-full hover:bg-primary hover:text-white transition shadow-neumorph-btn">' + btn.text + '</a>';
        }).join('');

        const social = (hero.socialMedia && hero.socialMedia.items || []).map(function (item) {
            return '<a href="' + item.href + '" target="_blank" rel="noopener noreferrer" class="text-2xl text-gray-600 hover:text-primary transition"><i class="' + item.icon + '"></i></a>';
        }).join('');

        const img = hero.profileImage || {};
        container.innerHTML =
            '<div class="flex flex-col md:flex-row items-center">' +
            '  <div class="md:w-1/2 mb-12 md:mb-0">' +
            '    <h1 class="text-5xl md:text-6xl font-bold mb-6">' +
            '      <span class="text-primary">' + (hero.greeting || '') + '</span><br>' +
            '      <span class="text-text-primary">' + (hero.name || '') + '</span>' +
            '    </h1>' +
            '    <p class="text-xl text-text-muted mb-8">' + (hero.title || '') + '</p>' +
            '    <p class="text-lg text-text-muted mb-8 max-w-lg">' + (hero.description || '') + '</p>' +
            '    <div class="flex flex-wrap gap-4">' + buttons + '</div>' +
            '    <div class="flex gap-4 mt-8">' + social + '</div>' +
            '  </div>' +
            '  <div class="md:w-1/2 relative">' +
            '    <div class="relative w-80 h-80 md:w-96 md:h-96 mx-auto">' +
            '      <div class="absolute inset-0 bg-white rounded-2xl shadow-neumorph transform rotate-3"></div>' +
            '      <div class="absolute inset-0 bg-white rounded-2xl overflow-hidden transform -rotate-3">' +
            '        <img src="' + (img.src || 'assets/images/profile/profile.jpg') + '" alt="' + (img.alt || 'Profile') + '" class="w-full h-full object-cover">' +
            '      </div>' +
            '      <div class="absolute -top-6 -left-6 w-16 h-16 bg-white rounded-xl shadow-neumorph flex items-center justify-center">' +
            '        <i class="fas fa-code text-primary text-2xl"></i>' +
            '      </div>' +
            '      <div class="absolute -bottom-6 -right-6 w-16 h-16 bg-white rounded-xl shadow-neumorph flex items-center justify-center">' +
            '        <i class="fas fa-laptop text-primary text-2xl"></i>' +
            '      </div>' +
            '    </div>' +
            '  </div>' +
            '</div>';
    }

    async function renderNav() {
        const raw = await loadJSON('navigation.json');
        const nav = getDataByLang(raw, getLang());
        if (!nav) return;

        const brand = document.getElementById('nav-brand');
        if (brand && nav.brand) {
            brand.textContent = nav.brand.text;
            if (nav.brand.href) brand.setAttribute('href', nav.brand.href);
        }

        const linksHtml = (nav.menuItems || []).map(function (item) {
            return '<a href="' + item.href + '" class="hover:text-primary transition nav-link">' + item.text + '</a>';
        }).join('');

        const navLinks = document.getElementById('nav-links');
        const mobileMenu = document.getElementById('mobile-menu');
        if (navLinks) navLinks.innerHTML = linksHtml;
        if (mobileMenu) {
            mobileMenu.innerHTML = '<div class="px-4 py-2 space-y-4">' +
                (nav.menuItems || []).map(function (item) {
                    return '<a href="' + item.href + '" class="block py-2 hover:text-primary transition nav-link">' + item.text + '</a>';
                }).join('') +
                '</div>';
        }
    }

    function updateLangButtons() {
        var lang = getLang();
        document.querySelectorAll('[data-lang]').forEach(function (btn) {
            var isActive = btn.getAttribute('data-lang') === lang;
            btn.classList.toggle('font-semibold', isActive);
            btn.classList.toggle('text-primary', isActive);
            btn.classList.toggle('text-gray-500', !isActive);
        });
    }

    async function renderSkillset() {
        const raw = await loadJSON('skillset.json');
        const skillset = getDataByLang(raw, getLang());
        const container = document.getElementById('skillset-content');
        if (!skillset || !container) return;

        const cardsHtml = skillset.cards.map(function (card) {
            const toolsHtml = card.tools.map(function (tool) {
                const colorClass = tool.iconClass || '';
                const colorStyle = tool.iconColor ? 'style="color: ' + tool.iconColor + '"' : '';
                return '<div class="flex items-center gap-2"><i class="' + tool.icon + ' ' + colorClass + '" ' + colorStyle + '></i><span class="text-sm">' + tool.name + '</span></div>';
            }).join('');

            const skillsHtml = card.skills.map(function (skill) {
                return '<span class="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">' + skill + '</span>';
            }).join('');

            return '<div class="neumorphic-card p-6 rounded-2xl">' +
                '  <div class="w-16 h-16 neumorphic-icon rounded-xl flex items-center justify-center mb-4">' +
                '    <i class="' + card.icon + ' text-primary text-3xl"></i>' +
                '  </div>' +
                '  <h3 class="text-xl font-semibold mb-2">' + card.title + '</h3>' +
                '  <p class="text-text-muted mb-4">' + card.subtitle + '</p>' +
                '  <p class="text-text-muted mb-4">' + card.description + '</p>' +
                '  <div class="space-y-2 mb-4">' + toolsHtml + '</div>' +
                '  <div class="flex flex-wrap gap-2">' + skillsHtml + '</div>' +
                '</div>';
        }).join('');

        container.innerHTML = '<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">' + cardsHtml + '</div>';
    }

    async function renderJourney() {
        const raw = await loadJSON('journey.json');
        const journey = getDataByLang(raw, getLang());
        const container = document.getElementById('journey-content');
        if (!journey || !container) return;

        // Render tabs
        const tabsHtml = journey.tabs.map(function (tab) {
            return '<button class="px-6 py-2 bg-primary text-white rounded-full transition" data-tab="' + tab.id + '">' + tab.label + '</button>';
        }).join('');

        // Render education content
        const educationHtml = journey.education.map(function (item) {
            const opacityClass = item.opacity ? 'opacity-60' : '';
            const badgeHtml = item.badge ? '<span class="' + item.badge.color + ' text-xs px-2 py-1 rounded-full">' + item.badge.text + '</span>' : '';
            
            return '<div class="relative pl-16 md:pl-24 ' + opacityClass + '">' +
                '  <div class="absolute left-0 top-0 w-4 h-4 bg-primary rounded-full -translate-x-2"></div>' +
                '  <div class="neumorphic-card p-6 rounded-2xl">' +
                '    <div class="flex items-start">' +
                '      <div class="education-icon mr-4">' +
                '        <div class="w-12 h-12 neumorphic-icon rounded-xl flex items-center justify-center">' +
                '          <i class="' + item.icon + ' text-primary text-xl"></i>' +
                '        </div>' +
                '      </div>' +
                '      <div>' +
                '        <h3 class="text-xl font-semibold mb-2">' + item.title + '</h3>' +
                '        <p class="text-primary mb-2">' + (item.class || '') + '</p>' +
                '        <p class="text-text-muted mb-2">' + item.period + '</p>' +
                '        ' + badgeHtml +
                '        <p class="mt-4">' + item.description + '</p>' +
                '      </div>' +
                '    </div>' +
                '  </div>' +
                '</div>';
        }).join('');

        // Render experience content
        const experienceHtml = journey.experience.map(function (item) {
            const tagsHtml = item.tags.map(function (tag) {
                return '<span class="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">' + tag + '</span>';
            }).join('');

            return '<div class="neumorphic-card p-6 rounded-2xl">' +
                '  <div class="flex items-start mb-4">' +
                '    <div class="w-12 h-12 neumorphic-icon rounded-xl flex items-center justify-center mr-4">' +
                '      <i class="' + item.icon + ' text-primary text-xl"></i>' +
                '    </div>' +
                '    <div>' +
                '      <h3 class="text-xl font-semibold">' + item.title + '</h3>' +
                '      <p class="text-primary">' + item.period + '</p>' +
                '    </div>' +
                '  </div>' +
                '  <p class="text-text-muted mb-4">' + item.description + '</p>' +
                '  <div class="flex flex-wrap gap-2">' + tagsHtml + '</div>' +
                '</div>';
        }).join('');

        container.innerHTML = 
            '<div class="text-center mb-16">' +
            '  <h2 class="text-4xl font-bold mb-4">' + journey.section.title + '</h2>' +
            '  <p class="text-lg text-text-muted">' + (journey.section.tag || '') + '</p>' +
            '</div>' +
            '<div class="max-w-5xl mx-auto">' +
            '  <div class="flex flex-wrap justify-center mb-12 gap-2">' + tabsHtml + '</div>' +
            '  <div id="content-education" class="journey-content">' +
            '    <div class="max-w-3xl mx-auto">' +
            '      <div class="relative">' +
            '        <div class="vertical-line"></div>' +
            '        <div class="space-y-8 journey-education">' + educationHtml + '</div>' +
            '      </div>' +
            '    </div>' +
            '  </div>' +
            '  <div id="content-experience" class="journey-content hidden">' +
            '    <div class="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">' + experienceHtml + '</div>' +
            '  </div>' +
            '</div>';
    }

    async function renderPortfolio() {
        const raw = await loadJSON('portfolio.json');
        const portfolio = getDataByLang(raw, getLang());
        const container = document.getElementById('portfolio-content');
        if (!portfolio || !container) return;

        // Render filters
        const filtersHtml = portfolio.filters.map(function (filter) {
            const activeClass = filter.active ? 'bg-primary text-white' : 'bg-gray-200 text-gray-700';
            return '<button class="px-4 py-2 ' + activeClass + ' rounded-full transition" data-filter="' + filter.id + '">' + filter.label + '</button>';
        }).join('');

        // Render projects
        const projectsHtml = portfolio.projects.map(function (project) {
            const tagsHtml = project.tags.map(function (tag) {
                return '<span class="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">' + tag + '</span>';
            }).join('');

            return '<div class="portfolio-item ' + project.category + '">' +
                '  <div class="neumorphic-card rounded-2xl overflow-hidden">' +
                '    <img src="' + project.image + '" alt="' + project.alt + '" class="w-full h-48 object-cover">' +
                '    <div class="p-6">' +
                '      <h3 class="text-xl font-semibold mb-2">' + project.title + '</h3>' +
                '      <p class="text-text-muted mb-4">' + project.description + '</p>' +
                '      <div class="flex gap-2 mb-4">' + tagsHtml + '</div>' +
                '      <div class="flex gap-4">' +
                '        <a href="' + project.link + '" class="text-primary hover:underline">View Project</a>' +
                '        <a href="' + project.link + '" class="text-text-muted hover:underline">Source Code</a>' +
                '      </div>' +
                '    </div>' +
                '  </div>' +
                '</div>';
        }).join('');

        container.innerHTML = 
            '<div class="text-center mb-16">' +
            '  <h2 class="text-4xl font-bold mb-4">' + portfolio.section.title + '</h2>' +
            '  <p class="text-lg text-text-muted">' + (portfolio.section.tag || '') + '</p>' +
            '</div>' +
            '<div class="flex justify-center mb-12">' +
            '  <div class="inline-flex flex-wrap justify-center gap-2 p-1 bg-gray-100 rounded-full">' + filtersHtml + '</div>' +
            '</div>' +
            '<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 portfolio-items">' + projectsHtml + '</div>';
    }

    async function renderAchievements() {
        const raw = await loadJSON('achievements.json');
        const achievements = getDataByLang(raw, getLang());
        const container = document.getElementById('achievements-content');
        if (!achievements || !container) return;

        // Combine achievements and certifications
        const allItems = [...achievements.achievements, ...achievements.certifications];
        
        const itemsHtml = allItems.map(function (item) {
            const iconColor = item.type === 'achievement' ? 'text-green-600' : 'text-blue-600';
            
            return '<div class="neumorphic-card p-6 rounded-2xl">' +
                '  <div class="flex items-start">' +
                '    <div class="w-12 h-12 neumorphic-icon rounded-xl flex items-center justify-center mr-4">' +
                '      <i class="' + item.icon + ' ' + iconColor + ' text-xl"></i>' +
                '    </div>' +
                '    <div>' +
                '      <h3 class="text-lg font-semibold">' + item.title + '</h3>' +
                '      <p class="text-text-muted">' + item.organization + ' - ' + item.year + '</p>' +
                '      <p class="text-text-muted mt-2">' + item.description + '</p>' +
                '    </div>' +
                '  </div>' +
                '</div>';
        }).join('');

        container.innerHTML = 
            '<div class="text-center mb-16">' +
            '  <h2 class="text-4xl font-bold mb-4">' + achievements.section.title + '</h2>' +
            '  <p class="text-lg text-text-muted">' + (achievements.section.tag || '') + '</p>' +
            '</div>' +
            '<div class="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">' + itemsHtml + '</div>';
    }

    async function renderBlog() {
        const raw = await loadJSON('blog.json');
        const blog = getDataByLang(raw, getLang());
        const container = document.getElementById('blog-content');
        if (!blog || !container) return;

        const postsHtml = blog.posts.map(function (post) {
            return '<div class="neumorphic-card rounded-2xl overflow-hidden">' +
                '  <div class="h-48 bg-gradient-to-br ' + post.image.gradient + ' flex items-center justify-center">' +
                '    <i class="' + post.image.icon + ' text-4xl text-primary"></i>' +
                '  </div>' +
                '  <div class="p-6">' +
                '    <div class="flex items-center gap-2 mb-2">' +
                '      <span class="text-sm text-text-muted">' + post.date + '</span>' +
                '      <span class="text-sm text-primary">• ' + post.category + '</span>' +
                '    </div>' +
                '    <h3 class="text-xl font-semibold mb-2">' + post.title + '</h3>' +
                '    <p class="text-text-muted mb-4">' + post.description + '</p>' +
                '    <a href="' + post.link + '" class="text-primary hover:underline">Read More →</a>' +
                '  </div>' +
                '</div>';
        }).join('');

        container.innerHTML = 
            '<div class="text-center mb-16">' +
            '  <h2 class="text-4xl font-bold mb-4">' + blog.section.title + '</h2>' +
            '  <p class="text-lg text-text-muted">' + (blog.section.tag || '') + '</p>' +
            '</div>' +
            '<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">' + postsHtml + '</div>';
    }

    async function renderContact() {
        const raw = await loadJSON('contact.json');
        const contact = getDataByLang(raw, getLang());
        const container = document.getElementById('contact-content');
        if (!contact || !container) return;

        // Render contact info
        const infoItemsHtml = contact.info.items.map(function (item) {
            return '<div class="flex items-center">' +
                '  <div class="w-12 h-12 neumorphic-icon rounded-xl flex items-center justify-center mr-4">' +
                '    <i class="' + item.icon + ' text-primary text-xl"></i>' +
                '  </div>' +
                '  <span class="text-lg">' + item.value + '</span>' +
                '</div>';
        }).join('');

        const socialItemsHtml = contact.socialMedia.items.map(function (item) {
            return '<a href="' + item.href + '" class="text-2xl text-gray-600 hover:text-primary transition" title="' + item.title + '">' +
                '  <i class="' + item.icon + '"></i>' +
                '</a>';
        }).join('');

        // Render form fields
        const formFieldsHtml = contact.form.fields.map(function (field) {
            const fieldHtml = field.type === 'textarea' 
                ? '<textarea id="' + field.id + '" placeholder="' + (field.placeholder || '') + '" rows="' + field.rows + '" class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-primary neumorphic-card-inner" required></textarea>'
                : '<input type="' + field.type + '" id="' + field.id + '" placeholder="' + (field.placeholder || '') + '" class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-primary neumorphic-card-inner" required>';
            
            return '<div class="mb-4">' +
                '  <label for="' + field.id + '" class="block text-sm font-medium mb-2">' + field.label + '</label>' +
                '  ' + fieldHtml +
                '</div>';
        }).join('');

        container.innerHTML = 
            '<div class="text-center mb-16">' +
            '  <h2 class="text-4xl font-bold mb-4">' + contact.section.title + '</h2>' +
            '  <p class="text-lg text-text-muted">' + (contact.section.tag || '') + '</p>' +
            '</div>' +
            '<div class="max-w-4xl mx-auto">' +
            '  <div class="grid md:grid-cols-2 gap-8">' +
            '    <div class="contact-info">' +
            '      <div class="neumorphic-card p-8 rounded-2xl">' +
            '        <div class="space-y-6">' + infoItemsHtml + '</div>' +
            '        <div class="mt-8">' +
            '          <div class="flex gap-4">' + socialItemsHtml + '</div>' +
            '        </div>' +
            '      </div>' +
            '    </div>' +
            '    <div class="neumorphic-card p-8 rounded-2xl">' +
            '      <h3 class="text-2xl font-semibold mb-6 text-center">' + contact.form.title + '</h3>' +
            '      <form id="contact-form">' + formFieldsHtml +
            '        <div class="mb-6">' +
            '          <button type="submit" class="w-full px-6 py-3 bg-primary text-white rounded-xl hover:bg-primary-dark transition shadow-neumorph-btn">' + contact.form.submitButton.text + '</button>' +
            '        </div>' +
            '      </form>' +
            '      <div id="form-message" class="mt-4 text-center hidden"></div>' +
            '    </div>' +
            '  </div>' +
            '</div>';
    }

    async function renderAll() {
        await Promise.all([
            renderHero(), 
            renderNav(), 
            renderSkillset(), 
            renderJourney(), 
            renderPortfolio(), 
            renderAchievements(), 
            renderBlog(), 
            renderContact()
        ]);
        updateLangButtons();
    }

    function init() {
        renderAll();

        document.querySelectorAll('[data-lang]').forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                var lang = this.getAttribute('data-lang');
                if (lang !== getLang()) {
                    setLang(lang);
                    renderAll();
                }
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();