# Personal Portfolio Website
A modern, responsive portfolio website built with HTML, Tailwind CSS, and Vanilla JavaScript.
## Features
- Responsive design that works on all devices
- Modern neumorphic UI with smooth animations
- Clean and semantic HTML5
- No build step required (Tailwind via CDN)
- Easy to customize
## Folder Structure
portfolio/ ├── index.html # Main HTML file ├── assets/ │ ├── images/ # All images │ │ ├── profile/ # Profile pictures │ │ └── portfolio/ # Portfolio project images │ ├── css/ │ │ └── custom.css # Custom CSS styles │ └── js/ │ └── main.js # JavaScript functionality └── README.md # This file

 
## How to Use
 
1. **Replace Profile Image**
   - Place your profile image at: `assets/images/profile/profile.jpg`
   - Recommended size: 600x600px (square aspect ratio)
 
2. **Add Portfolio Projects**
   - Add project images to: `assets/images/portfolio/`
   - Name them sequentially: `project-1.jpg`, `project-2.jpg`, etc.
   - Update the portfolio section in `index.html` with your project details
 
3. **Customize Content**
   - Open `index.html` and update the following sections:
     - Hero section with your name and title
     - About section with your bio
     - Services/What I Do section
     - Portfolio projects
     - Resume/Experience section
     - Contact information
 
4. **Update Social Media Links**
   - Find the social media icons in the header and footer
   - Update the `href` attributes with your profile URLs
 
5. **Customize Colors**
   - The primary color can be changed in the `<style>` section of `index.html`
   - Look for the `--primary-color` variable and update its value
 
## Browser Support
 
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
 
## License
 
This project is open source and available under the [MIT License](LICENSE).
 
## Credits
 
- [Tailwind CSS](https://tailwindcss.com/)
- [Font Awesome](https://fontawesome.com/)
- [Google Fonts](https://fonts.google.com/)