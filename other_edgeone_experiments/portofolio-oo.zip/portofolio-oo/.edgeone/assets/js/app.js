// Smart Data Renderer - Load & Render langsung dari JSON
// No placeholder HTML, no FOUC (Flash of Unstyled Content)

class SmartPortfolioApp {
    constructor() {
        this.basePath = 'data/';
        this.loadedData = {};
        this.cacheKey = 'portfolio_cache_v2';
        this.cacheExpiry = 24 * 60 * 60 * 1000;
        this.renderQueue = [];
    }

    // Load JSON dengan smart caching
    async loadJSON(filename) {
        const cached = this.getCacheData(filename);
        if (cached) return cached;

        try {
            const response = await fetch(`${this.basePath}${filename}`);
            if (!response.ok) throw new Error(`Failed to load ${filename}`);
            
            const data = await response.json();
            this.setCacheData(filename, data);
            return data;
        } catch (error) {
            console.error(`❌ Error loading ${filename}:`, error);
            return null;
        }
    }

    // Cache management
    getCacheData(filename) {
        try {
            const cache = JSON.parse(localStorage.getItem(this.cacheKey) || '{}');
            const item = cache[filename];
            
            if (item && Date.now() - item.timestamp < this.cacheExpiry) {
                return item.data;
            }
        } catch (e) {
            console.warn('Cache read error:', e);
        }
        return null;
    }

    setCacheData(filename, data) {
        try {
            const cache = JSON.parse(localStorage.getItem(this.cacheKey) || '{}');
            cache[filename] = { data, timestamp: Date.now() };
            localStorage.setItem(this.cacheKey, JSON.stringify(cache));
        } catch (e) {
            console.warn('Cache write error:', e);
        }
    }

    // Render Hero Section dari JSON
    async renderHero() {
        const hero = await this.loadJSON('hero.json');
        if (!hero) return;

        const container = document.getElementById('hero-content');
        if (!container) return;

        // Social media links
        const socialLinks = hero.socialMedia.items
            .map(item => `
                <a href="${item.href}" 
                   title="${item.title}"
                   target="_blank" rel="noopener noreferrer"
                   class="w-12 h-12 rounded-lg flex items-center justify-center neumorphic-icon transition hover:shadow-neumorph-lg">
                    <i class="${item.icon}"></i>
                </a>
            `).join('');

        // Best skills icons
        const skillsIcons = hero.bestSkills.items
            .map(item => `
                <div class="flex flex-col items-center">
                    <i class="${item.icon} text-3xl ${item.color}"></i>
                    <span class="text-xs mt-1 text-text-muted">${item.name}</span>
                </div>
            `).join('');

        // Buttons
        const buttons = hero.buttons
            .map(btn => {
                if (btn.type === 'primary') {
                    return `<a href="${btn.href}" class="btn-neumorph bg-primary text-white px-6 py-2 rounded-2xl shadow-neumorph hover:shadow-neumorph-lg transition">${btn.text}</a>`;
                } else {
                    return `<a href="${btn.href}" class="btn-neumorph text-primary border-2 border-primary bg-white px-6 py-2 rounded-2xl shadow-neumorph hover:bg-primary/10 transition">${btn.text}</a>`;
                }
            }).join('');

        container.innerHTML = `
            <div class="flex flex-col md:flex-row items-center gap-12">
                <div class="md:w-1/2">
                    <p class="text-primary text-lg mb-2 font-medium">${hero.status}</p>
                    <h1 class="text-4xl md:text-6xl font-bold mb-6">
                        ${hero.greeting} <span class="text-primary">${hero.name}</span><br>
                        <span class="text-primary">${hero.title}</span>
                    </h1>
                    <p class="text-gray-600 mb-8 max-w-lg">${hero.description}</p>
                    
                    <div class="flex flex-wrap gap-4 mb-8">
                        ${buttons}
                    </div>
                    
                    <div class="flex items-center space-x-8">
                        <div>
                            <p class="text-sm text-gray-500 mb-2">${hero.socialMedia.label}</p>
                            <div class="flex space-x-4">
                                ${socialLinks}
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="md:w-1/2 flex justify-center">
                    <div class="grid grid-cols-2 gap-8">
                        ${skillsIcons}
                    </div>
                </div>
            </div>
        `;
    }

    // Render Navigation dari JSON
    async renderNavigation() {
        const nav = await this.loadJSON('navigation.json');
        if (!nav) return;

        const navLinks = document.querySelector('.nav-links');
        const mobileLinks = document.getElementById('mobile-menu');
        
        if (!navLinks || !mobileLinks) return;

        const linksHTML = nav.items
            .map(item => `<a href="${item.href}" class="nav-link text-gray-700 hover:text-primary transition">${item.label}</a>`)
            .join('');

        const mobileLinksHTML = nav.items
            .map(item => `<a href="${item.href}" class="nav-link block py-2 text-gray-700 hover:text-primary">${item.label}</a>`)
            .join('');

        navLinks.innerHTML = linksHTML;
        mobileLinks.innerHTML = mobileLinksHTML;
    }

    // Render Contact Section
    async renderContact() {
        const contact = await this.loadJSON('contact.json');
        if (!contact) return;

        const container = document.getElementById('contact-content');
        if (!container) return;

        const contactItems = contact.info.items
            .map(item => {
                if (item.href) {
                    return `
                        <div class="flex items-start gap-4">
                            <i class="${item.icon} text-2xl text-primary mt-1"></i>
                            <div>
                                <h3 class="font-semibold">${item.label}</h3>
                                <a href="${item.href}" class="text-gray-600 hover:text-primary transition">${item.value}</a>
                            </div>
                        </div>
                    `;
                }
                return `
                    <div class="flex items-start gap-4">
                        <i class="${item.icon} text-2xl text-primary mt-1"></i>
                        <div>
                            <h3 class="font-semibold">${item.label}</h3>
                            <p class="text-gray-600">${item.value}</p>
                        </div>
                    </div>
                `;
            }).join('');

        const socialLinks = contact.socialMedia.items
            .map(item => `
                <a href="${item.href}" 
                   title="${item.title}"
                   target="_blank" rel="noopener noreferrer"
                   class="w-12 h-12 rounded-lg flex items-center justify-center neumorphic-icon transition hover:shadow-neumorph-lg">
                    <i class="${item.icon}"></i>
                </a>
            `).join('');

        container.innerHTML = `
            <div class="grid md:grid-cols-2 gap-12">
                <div>
                    <h3 class="text-2xl font-bold mb-4">${contact.info.title}</h3>
                    <p class="text-gray-600 mb-8">${contact.info.description}</p>
                    <div class="space-y-6">
                        ${contactItems}
                    </div>
                </div>
                
                <div>
                    <div class="bg-white p-8 rounded-lg shadow-neumorph">
                        <form class="space-y-4">
                            <input type="text" placeholder="Your Name" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                            <input type="email" placeholder="Your Email" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                            <textarea placeholder="Message" rows="5" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary"></textarea>
                            <button type="submit" class="w-full bg-primary text-white py-2 rounded-lg hover:bg-primary-dark transition">Send Message</button>
                        </form>
                    </div>
                    
                    <div class="mt-8">
                        <p class="text-sm text-gray-500 mb-4">${contact.socialMedia.label}</p>
                        <div class="flex space-x-4">
                            ${socialLinks}
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Render Portfolio/Projects
    async renderPortfolio() {
        const portfolio = await this.loadJSON('portfolio.json');
        if (!portfolio) return;

        const container = document.getElementById('portfolio-content');
        if (!container) return;

        const projects = portfolio.items
            .map(project => `
                <div class="bg-white rounded-lg shadow-neumorph overflow-hidden hover:shadow-neumorph-lg transition">
                    ${project.image ? `<img src="${project.image}" alt="${project.title}" class="w-full h-48 object-cover">` : '<div class="w-full h-48 bg-gray-200"></div>'}
                    <div class="p-6">
                        <h3 class="text-xl font-bold mb-2">${project.title}</h3>
                        <p class="text-gray-600 mb-4">${project.description}</p>
                        <div class="flex gap-2 mb-4">
                            ${project.tags.map(tag => `<span class="text-xs bg-primary/10 text-primary px-2 py-1 rounded">${tag}</span>`).join('')}
                        </div>
                        ${project.link ? `<a href="${project.link}" target="_blank" rel="noopener noreferrer" class="text-primary hover:text-primary-dark transition">View Project →</a>` : ''}
                    </div>
                </div>
            `).join('');

        container.innerHTML = `<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">${projects}</div>`;
    }

    // Render Skills
    async renderSkills() {
        const skills = await this.loadJSON('skillset.json');
        if (!skills) return;

        const container = document.getElementById('skills-content');
        if (!container) return;

        const skillsHTML = skills.categories
            .map(category => `
                <div class="mb-8">
                    <h3 class="text-lg font-bold mb-4">${category.name}</h3>
                    <div class="flex flex-wrap gap-2">
                        ${category.items.map(item => `
                            <span class="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm">${item}</span>
                        `).join('')}
                    </div>
                </div>
            `).join('');

        container.innerHTML = skillsHTML;
    }

    // Render Journey/Timeline
    async renderJourney() {
        const journey = await this.loadJSON('journey.json');
        if (!journey) return;

        const container = document.getElementById('journey-content');
        if (!container) return;

        const timeline = journey.items
            .map((item, index) => `
                <div class="mb-8 flex gap-4">
                    <div class="flex flex-col items-center">
                        <div class="w-4 h-4 rounded-full bg-primary"></div>
                        ${index < journey.items.length - 1 ? '<div class="w-1 h-16 bg-gray-300 mt-2"></div>' : ''}
                    </div>
                    <div class="pb-8">
                        <h3 class="text-lg font-bold">${item.title}</h3>
                        <p class="text-primary text-sm">${item.period}</p>
                        <p class="text-gray-600 mt-2">${item.description}</p>
                    </div>
                </div>
            `).join('');

        container.innerHTML = timeline;
    }

    // Render Achievements
    async renderAchievements() {
        const achievements = await this.loadJSON('achievements.json');
        if (!achievements) return;

        const container = document.getElementById('achievements-content');
        if (!container) return;

        const cards = achievements.items
            .map(achievement => `
                <div class="text-center p-6 rounded-lg shadow-neumorph">
                    <i class="${achievement.icon} text-4xl text-primary mb-4"></i>
                    <h3 class="text-2xl font-bold text-primary">${achievement.value}</h3>
                    <p class="text-gray-600 mt-2">${achievement.label}</p>
                </div>
            `).join('');

        container.innerHTML = `<div class="grid md:grid-cols-4 gap-6">${cards}</div>`;
    }

    // Render Blog
    async renderBlog() {
        const blog = await this.loadJSON('blog.json');
        if (!blog) return;

        const container = document.getElementById('blog-content');
        if (!container) return;

        const posts = blog.items
            .map(post => `
                <div class="bg-white rounded-lg shadow-neumorph overflow-hidden hover:shadow-neumorph-lg transition">
                    ${post.image ? `<img src="${post.image}" alt="${post.title}" class="w-full h-40 object-cover">` : '<div class="w-full h-40 bg-gray-200"></div>'}
                    <div class="p-6">
                        <p class="text-primary text-xs font-medium mb-2">${post.date}</p>
                        <h3 class="text-lg font-bold mb-2">${post.title}</h3>
                        <p class="text-gray-600 mb-4">${post.excerpt}</p>
                        <a href="${post.link || '#'}" class="text-primary hover:text-primary-dark transition">Read More →</a>
                    </div>
                </div>
            `).join('');

        container.innerHTML = `<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">${posts}</div>`;
    }

    // Main init - render semua section
    async initialize() {
        // Show loading state
        document.body.classList.add('loading');

        try {
            // Load semua data parallel untuk kecepatan
            await Promise.all([
                this.renderHero(),
                this.renderNavigation(),
                this.renderContact(),
                this.renderPortfolio(),
                this.renderSkills(),
                this.renderJourney(),
                this.renderAchievements(),
                this.renderBlog()
            ]);

            console.log('✅ Portfolio loaded successfully');
        } catch (error) {
            console.error('❌ Error initializing portfolio:', error);
        } finally {
            // Hide loading state
            document.body.classList.remove('loading');
        }
    }
}

// Jalankan saat DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        const app = new SmartPortfolioApp();
        app.initialize();
    });
} else {
    const app = new SmartPortfolioApp();
    app.initialize();
}
