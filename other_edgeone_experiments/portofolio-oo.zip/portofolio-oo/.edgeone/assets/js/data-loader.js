// Data Loader untuk Portfolio Website - OPTIMIZED VERSION
// Dengan localStorage caching & minimal flickering

class DataLoader {
    constructor() {
        this.basePath = 'data/';
        this.loadedData = {};
        this.cacheKey = 'portfolio_cache_v1';
        this.cacheExpiry = 24 * 60 * 60 * 1000; // 24 jam
    }

    // Method untuk load JSON file dengan caching
    async loadJSON(filename) {
        try {
            const cacheData = this.getCacheData(filename);
            
            // Jika ada di cache dan masih valid, gunakan cache
            if (cacheData) {
                console.log(`📦 Using cached data: ${filename}`);
                this.loadedData[filename.replace('.json', '')] = cacheData;
                return cacheData;
            }

            // Jika tidak ada cache, fetch dari server
            const url = `${this.basePath}${filename}`;
            console.log(`🔄 Fetching JSON: ${url}`);
            const response = await fetch(url);
            
            if (!response.ok) {
                throw new Error(`Failed to load ${filename}: ${response.statusText} (${response.status})`);
            }
            
            const data = await response.json();
            this.loadedData[filename.replace('.json', '')] = data;
            
            // Simpan ke cache
            this.setCacheData(filename, data);
            console.log(`✅ ${filename} loaded & cached successfully`);
            return data;
        } catch (error) {
            console.error(`❌ Error loading ${filename}:`, error);
            
            // Fallback: coba ambil dari cache meski expired
            const expiredCache = this.getCacheData(filename, true);
            if (expiredCache) {
                console.warn(`⚠️ Using expired cache for ${filename}`);
                this.loadedData[filename.replace('.json', '')] = expiredCache;
                return expiredCache;
            }
            
            return null;
        }
    }

    // Get data from localStorage
    getCacheData(filename, ignoreExpiry = false) {
        try {
            const cache = JSON.parse(localStorage.getItem(this.cacheKey) || '{}');
            const fileCache = cache[filename];
            
            if (!fileCache) return null;
            
            // Check expiry
            if (!ignoreExpiry) {
                const now = Date.now();
                if (now - fileCache.timestamp > this.cacheExpiry) {
                    return null; // Cache expired
                }
            }
            
            return fileCache.data;
        } catch (e) {
            return null;
        }
    }

    // Set data to localStorage
    setCacheData(filename, data) {
        try {
            const cache = JSON.parse(localStorage.getItem(this.cacheKey) || '{}');
            cache[filename] = {
                data: data,
                timestamp: Date.now()
            };
            localStorage.setItem(this.cacheKey, JSON.stringify(cache));
        } catch (e) {
            console.warn('LocalStorage tidak tersedia, cache dinonaktifkan');
        }
    }

    // Clear all cache
    clearCache() {
        try {
            localStorage.removeItem(this.cacheKey);
            console.log('✅ Cache cleared');
        } catch (e) {
            console.warn('Tidak bisa clear cache');
        }
    }

    // Load Navigation
    async loadNavigation() {
        const data = await this.loadJSON('navigation.json');
        if (!data) return;

        // Update brand
        const brand = document.querySelector('nav a.text-2xl');
        if (brand && data.brand) {
            brand.textContent = data.brand.text;
            brand.href = data.brand.href;
        }

        // Update desktop menu
        const desktopMenu = document.querySelector('nav .hidden.md\\:flex');
        if (desktopMenu && data.menuItems) {
            desktopMenu.innerHTML = data.menuItems.map(item => 
                `<a href="${item.href}" class="nav-link text-gray-700 hover:text-primary transition">${item.text}</a>`
            ).join('');
        }

        // Update mobile menu
        const mobileMenu = document.querySelector('#mobile-menu');
        if (mobileMenu && data.menuItems) {
            const menuContent = mobileMenu.querySelector('.px-4.py-2');
            if (menuContent) {
                menuContent.innerHTML = data.menuItems.map(item => 
                    `<a href="${item.href}" class="nav-link block py-2 text-gray-700 hover:text-primary">${item.text}</a>`
                ).join('');
            }
        }

        // Re-initialize smooth scrolling for new links
        this.initSmoothScroll();
    }

    // Load Hero Section
    async loadHero() {
        const data = await this.loadJSON('hero.json');
        if (!data) {
            console.error('Failed to load hero.json');
            return;
        }

        console.log('Hero data loaded:', data);

        // Find hero section - more flexible selector
        const heroSection = document.querySelector('#home');
        if (!heroSection) {
            console.error('Hero section not found!');
            return;
        }

        const leftSection = heroSection.querySelector('.md\\:w-1\\/2') || 
                           heroSection.querySelector('[class*="md:w-1/2"]') ||
                           heroSection.querySelector('div > div:first-child');
        
        if (!leftSection) {
            console.error('Left section not found!');
            return;
        }

        // Update status - find first p with text-primary class
        const statusEl = leftSection.querySelector('p.text-primary');
        if (statusEl && data.status) {
            statusEl.textContent = data.status;
            console.log('Status updated:', data.status);
        }

        // Update heading
        const heading = leftSection.querySelector('h1');
        if (heading && data.greeting && data.name && data.title) {
            heading.innerHTML = `
                ${data.greeting} <span class="text-primary">${data.name}</span><br>
                <span class="text-primary">${data.title}</span>
            `;
            console.log('Heading updated');
        }

        // Update description - find p with text-gray-600 after h1
        const desc = leftSection.querySelector('p.text-gray-600') || 
                    leftSection.querySelector('p.max-w-lg');
        if (desc && data.description) {
            desc.textContent = data.description;
            console.log('Description updated');
        }

        // Update buttons
        const buttonsContainer = leftSection.querySelector('.flex.flex-wrap.gap-4.mb-8');
        if (buttonsContainer && data.buttons) {
            buttonsContainer.innerHTML = data.buttons.map(btn => {
                if (btn.type === 'primary') {
                    return `
                        <a href="${btn.href}"
                            class="btn-neumorph bg-primary text-white px-4 py-2 rounded-2xl shadow-neumorph hover:bg-primary-dark hover:text-white">
                            ${btn.text}
                        </a>
                    `;
                } else {
                    return `
                        <a href="${btn.href}"
                            class="btn-neumorph text-primary border-2 border-primary bg-white px-4 py-2 rounded-2xl shadow-neumorph hover:bg-primary/10">
                            ${btn.text}
                        </a>
                    `;
                }
            }).join('');
            console.log('Buttons updated');
        }

        // Update social media
        if (data.socialMedia) {
            const socialSkillsContainer = leftSection.querySelector('.flex.items-center.space-x-8');
            if (socialSkillsContainer) {
                const socialContainer = socialSkillsContainer.children[0];
                if (socialContainer) {
                    const label = socialContainer.querySelector('p.text-sm');
                    if (label) label.textContent = data.socialMedia.label;

                    const iconsContainer = socialContainer.querySelector('.flex.space-x-4');
                    if (iconsContainer) {
                        iconsContainer.innerHTML = data.socialMedia.items.map(item => `
                            <a href="${item.href || '#'}"
                                class="w-12 h-12 rounded-lg flex items-center justify-center neumorphic-icon"
                                title="${item.title || item.name}">
                                <i class="${item.icon}"></i>
                            </a>
                        `).join('');
                        console.log('Social media updated');
                    }
                }

                // Update best skills
                if (data.bestSkills) {
                    const skillsContainer = socialSkillsContainer.children[1];
                    if (skillsContainer) {
                        const label = skillsContainer.querySelector('p.text-sm');
                        if (label) label.textContent = data.bestSkills.label;

                        const iconsContainer = skillsContainer.querySelector('.flex.space-x-4');
                        if (iconsContainer) {
                            iconsContainer.innerHTML = data.bestSkills.items.map(item => `
                                <div class="w-10 h-10 rounded-full bg-white shadow-lg flex items-center justify-center">
                                    <i class="${item.icon} ${item.color}"></i>
                                </div>
                            `).join('');
                            console.log('Best skills updated');
                        }
                    }
                }
            }
        }

        // Update profile image
        if (data.profileImage) {
            const profileImg = document.querySelector('#home img[alt="Profile"]');
            if (profileImg) {
                profileImg.src = data.profileImage.src;
                profileImg.alt = data.profileImage.alt;
                console.log('Profile image updated');
            }
        }

        // Update floating elements
        if (data.floatingElements) {
            data.floatingElements.forEach((el, index) => {
                const floatingEls = document.querySelectorAll('#home .absolute.w-16.h-16');
                if (floatingEls[index]) {
                    const icon = floatingEls[index].querySelector('i');
                    if (icon) {
                        icon.className = `${el.icon} text-primary text-2xl`;
                        console.log(`Floating element ${index} updated`);
                    }
                }
            });
        }
        
        console.log('✅ Hero section updated successfully');
    }

    // Load Skillset Section
    async loadSkillset() {
        const data = await this.loadJSON('skillset.json');
        if (!data) return;

        const section = document.querySelector('#about');
        if (!section) return;

        // Update section header
        const header = section.querySelector('.text-center.mb-16');
        if (header && data.section) {
            const tag = header.querySelector('p.text-primary');
            const title = header.querySelector('h2');
            if (tag) tag.textContent = data.section.tag;
            if (title) title.textContent = data.section.title;
        }

        // Update cards
        const cardsContainer = section.querySelector('.grid');
        if (cardsContainer && data.cards) {
            cardsContainer.innerHTML = data.cards.map(card => `
                <div class="neumorphic-card p-8 rounded-2xl transition-all duration-300 hover:shadow-neumorph-lg hover:-translate-y-1">
                    <div class="w-16 h-16 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-6 shadow-neumorph-sm">
                        <i class="${card.icon} text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-3 text-text-primary">${card.title}</h3>
                    <p class="text-text-muted mb-4">${card.subtitle}</p>
                    <p class="text-text-muted mb-4">${card.description}</p>
                    <div class="mb-3">
                        <p class="text-sm font-semibold text-text-primary mb-3">Tools:</p>
                        <div class="flex flex-wrap gap-3">
                            ${card.tools.map(tool => {
                                const iconStyle = tool.iconColor ? `style="color: ${tool.iconColor};"` : '';
                                const iconClass = tool.iconClass || '';
                                return `
                                    <div class="flex items-center gap-2 px-3 py-2 bg-white rounded-lg shadow-neumorph-sm hover:shadow-neumorph transition">
                                        <i class="${tool.icon} text-lg ${iconClass}" ${iconStyle}></i>
                                        <span class="text-sm text-text-muted">${tool.name}</span>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                    <div>
                        <p class="text-sm font-semibold text-text-primary mb-2">Keahlian:</p>
                        <p class="text-text-muted text-sm">${card.skills.join(', ')}.</p>
                    </div>
                </div>
            `).join('');
        }
    }

    // Load Journey Section
    async loadJourney() {
        const data = await this.loadJSON('journey.json');
        if (!data) return;

        const section = document.querySelector('#journey');
        if (!section) return;

        // Update section header
        const header = section.querySelector('.text-center.mb-16');
        if (header && data.section) {
            const tag = header.querySelector('p.text-primary');
            const title = header.querySelector('h2');
            if (tag) tag.textContent = data.section.tag;
            if (title) title.textContent = data.section.title;
        }

        // Update tabs
        const tabsContainer = section.querySelector('.flex.flex-wrap.justify-center.mb-12');
        if (tabsContainer && data.tabs) {
            tabsContainer.innerHTML = data.tabs.map((tab, index) => `
                <button id="tab-${tab.id}" class="journey-tab px-8 py-3 border-b-2 ${index === 0 ? 'border-primary text-primary font-medium' : 'border-transparent text-gray-600 hover:text-primary'} transition">
                    ${tab.label}
                </button>
            `).join('');
        }

        // Render Education
        const educationContainer = document.querySelector('#content-education .space-y-8');
        if (educationContainer && data.education) {
            educationContainer.innerHTML = data.education.map(edu => {
                const isActive = edu.current ? 'bg-primary' : (edu.status === 'completed' ? 'bg-white' : 'bg-gray-200');
                const borderStyle = edu.current ? 'border-2 border-primary/20' : '';
                const opacityClass = edu.opacity ? 'opacity-75' : '';
                
                let badgeHtml = '';
                if (edu.badge) {
                    badgeHtml = `<span class="inline-block px-2 py-1 ${edu.badge.color} text-xs rounded-full font-medium">${edu.badge.text}</span>`;
                }

                let additionalInfoHtml = '';
                if (edu.class) {
                    additionalInfoHtml = `<p class="text-text-muted text-sm mb-1">${edu.class}</p>`;
                }

                const bgClass = edu.status === 'planned' ? 'bg-gray-50' : 'bg-white';
                const titleClass = edu.status === 'planned' ? 'text-gray-500' : 'text-text-primary';
                const badgeClass = edu.status === 'planned' ? 'bg-gray-200 text-gray-500' : 'bg-primary/10 text-primary';
                const iconClass = edu.current ? 'text-white' : (edu.status === 'completed' ? 'text-primary' : 'text-gray-400');
                const iconSize = edu.status === 'planned' ? 'text-2xl' : 'text-xl';
                const iconZIndex = edu.status === 'completed' ? 'relative z-20' : 'relative';

                return `
                    <div class="relative flex items-start">
                        <div class="flex-shrink-0 z-10 relative">
                            <div class="w-16 h-16 rounded-full ${isActive} border-4 border-white shadow-neumorph flex items-center justify-center relative z-10 ${edu.status === 'completed' ? 'overflow-hidden' : ''}">
                                ${edu.status === 'completed' ? '<div class="absolute inset-0 bg-primary/10"></div>' : ''}
                                <i class="${edu.icon} ${iconClass} ${iconSize} ${iconZIndex}"></i>
                            </div>
                        </div>
                        <div class="ml-6 flex-1">
                            <div class="${bgClass} p-6 rounded-2xl shadow-neumorph hover:shadow-neumorph-lg transition ${borderStyle} ${opacityClass}">
                                ${edu.badge ? `<div class="flex items-center gap-2 mb-3">` : ''}
                                <span class="inline-block px-3 py-1 ${badgeClass} text-sm rounded-full mb-3">${edu.period}</span>
                                ${badgeHtml}
                                ${edu.badge ? `</div>` : ''}
                                <h4 class="text-xl font-semibold mb-2 ${titleClass}">${edu.title}</h4>
                                ${additionalInfoHtml}
                                <p class="text-text-muted text-sm">${edu.description}</p>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        }

        // Render Experience
        const experienceContainer = document.querySelector('#content-experience .grid');
        if (experienceContainer && data.experience) {
            experienceContainer.innerHTML = data.experience.map(exp => `
                <div class="bg-white p-6 rounded-2xl shadow-neumorph hover:shadow-neumorph-lg transition">
                    <div class="flex items-start">
                        <div class="w-16 h-16 rounded-xl bg-primary/10 text-primary flex items-center justify-center mr-4 flex-shrink-0">
                            <i class="${exp.icon} text-2xl"></i>
                        </div>
                        <div class="flex-1">
                            <span class="inline-block px-3 py-1 bg-primary/10 text-primary text-sm rounded-full mb-2">${exp.period}</span>
                            <h3 class="text-xl font-bold mb-2">${exp.title}</h3>
                            <p class="text-text-muted text-sm mb-2">${exp.description}</p>
                            <div class="flex flex-wrap gap-2 mt-2">
                                ${exp.tags.map(tag => `<span class="text-xs px-2 py-1 bg-gray-100 rounded">${tag}</span>`).join('')}
                            </div>
                        </div>
                    </div>
                </div>
            `).join('');
        }

        // Re-initialize journey tabs
        this.initJourneyTabs();
    }

    // Load Portfolio Section
    async loadPortfolio() {
        const data = await this.loadJSON('portfolio.json');
        if (!data) return;

        const section = document.querySelector('#portfolio');
        if (!section) return;

        // Update section header
        const header = section.querySelector('.text-center.mb-16');
        if (header && data.section) {
            const tag = header.querySelector('p.text-primary');
            const title = header.querySelector('h2');
            if (tag) tag.textContent = data.section.tag;
            if (title) title.textContent = data.section.title;
        }

        // Update filters
        const filtersContainer = section.querySelector('.flex.justify-center.mb-12 > div');
        if (filtersContainer && data.filters) {
            filtersContainer.innerHTML = data.filters.map(filter => `
                <button class="portfolio-filter-btn px-6 py-2 rounded-full ${filter.active ? 'bg-primary text-white' : 'hover:bg-gray-200'} transition" data-filter="${filter.id}">
                    ${filter.label}
                </button>
            `).join('');
        }

        // Update projects
        const projectsContainer = section.querySelector('.grid.grid-cols-1');
        if (projectsContainer && data.projects) {
            projectsContainer.innerHTML = data.projects.map(project => `
                <div class="group relative overflow-hidden rounded-2xl shadow-neumorph hover:shadow-neumorph-lg transition portfolio-item" data-category="${project.category}">
                    <img src="${project.image}" alt="${project.alt}" class="w-full h-64 object-cover">
                    <div class="absolute inset-0 bg-primary/90 flex flex-col justify-center items-center opacity-0 group-hover:opacity-100 transition-opacity p-6 text-center">
                        <h3 class="text-xl font-bold text-white mb-2">${project.title}</h3>
                        <p class="text-white/80 mb-4">${project.description}</p>
                        <a href="${project.link}"
                            class="px-4 py-2 bg-white text-primary rounded-full text-sm font-medium hover:bg-gray-100 transition">
                            View Project
                        </a>
                    </div>
                </div>
            `).join('');
        }

        // Initialize portfolio filter
        this.initPortfolioFilter();
    }

    // Load Achievements Section
    async loadAchievements() {
        const data = await this.loadJSON('achievements.json');
        if (!data) return;

        const section = document.querySelector('#achievements');
        if (!section) return;

        // Update section header
        const header = section.querySelector('.text-center.mb-16');
        if (header && data.section) {
            const tag = header.querySelector('p.text-primary');
            const title = header.querySelector('h2');
            if (tag) tag.textContent = data.section.tag;
            if (title) title.textContent = data.section.title;
        }

        // Combine achievements and certifications
        const allItems = [...(data.achievements || []), ...(data.certifications || [])];
        const container = section.querySelector('.grid');
        
        if (container && allItems.length > 0) {
            container.innerHTML = allItems.map(item => `
                <div class="bg-surface p-6 rounded-2xl shadow-neumorph hover:shadow-neumorph-lg transition">
                    <div class="flex items-start">
                        <div class="w-16 h-16 rounded-xl bg-primary/10 text-primary flex items-center justify-center mr-4 flex-shrink-0">
                            <i class="${item.icon} text-2xl"></i>
                        </div>
                        <div>
                            <span class="inline-block px-3 py-1 bg-primary/10 text-primary text-sm rounded-full mb-2">${item.year}</span>
                            <h3 class="text-xl font-bold mb-2">${item.title}</h3>
                            <p class="text-gray-600 text-sm mb-2">${item.organization}</p>
                            <p class="text-text-muted text-sm">${item.description}</p>
                            ${item.link ? `<a href="${item.link}" class="text-primary hover:underline text-sm mt-2 inline-block">View Certificate →</a>` : ''}
                        </div>
                    </div>
                </div>
            `).join('');
        }
    }

    // Load Blog Section
    async loadBlog() {
        const data = await this.loadJSON('blog.json');
        if (!data) return;

        const section = document.querySelector('#blog');
        if (!section) return;

        // Update section header
        const header = section.querySelector('.text-center.mb-16');
        if (header && data.section) {
            const tag = header.querySelector('p.text-primary');
            const title = header.querySelector('h2');
            if (tag) tag.textContent = data.section.tag;
            if (title) title.textContent = data.section.title;
        }

        // Update posts
        const postsContainer = section.querySelector('.grid');
        if (postsContainer && data.posts) {
            postsContainer.innerHTML = data.posts.map(post => `
                <div class="neumorphic-card rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-neumorph-lg hover:-translate-y-1">
                    <div class="h-48 bg-gradient-to-br ${post.image.gradient} flex items-center justify-center">
                        <i class="${post.image.icon} text-6xl text-primary/30"></i>
                    </div>
                    <div class="p-6">
                        <span class="inline-block px-3 py-1 bg-primary/10 text-primary text-xs rounded-full mb-3">${post.category}</span>
                        <h3 class="text-xl font-bold mb-3 text-text-primary">${post.title}</h3>
                        <p class="text-text-muted text-sm mb-4">${post.description}</p>
                        <div class="flex items-center justify-between">
                            <span class="text-text-muted text-xs">${post.date}</span>
                            <a href="${post.link}" class="text-primary hover:text-primary-dark font-medium text-sm flex items-center">
                                Read More <i class="fas fa-arrow-right ml-2"></i>
                            </a>
                        </div>
                    </div>
                </div>
            `).join('');
        }
    }

    // Load Contact Section
    async loadContact() {
        const data = await this.loadJSON('contact.json');
        if (!data) return;

        const section = document.querySelector('#contact');
        if (!section) return;

        // Update section header
        const header = section.querySelector('.text-center.mb-16');
        if (header && data.section) {
            const tag = header.querySelector('p.text-primary');
            const title = header.querySelector('h2');
            if (tag) tag.textContent = data.section.tag;
            if (title) title.textContent = data.section.title;
        }

        // Update contact info
        if (data.info) {
            const infoContainer = section.querySelector('.grid > div:first-child');
            if (infoContainer) {
                const title = infoContainer.querySelector('h3.text-2xl');
                const desc = infoContainer.querySelector('p.text-gray-600');
                
                if (title) title.textContent = data.info.title;
                if (desc) desc.textContent = data.info.description;

                // Update contact items
                const itemsContainer = infoContainer.querySelector('.space-y-6');
                if (itemsContainer && data.info.items) {
                    itemsContainer.innerHTML = data.info.items.map(item => `
                        <div class="flex items-start">
                            <div class="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center mr-4">
                                <i class="${item.icon}"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold">${item.label}</h4>
                                ${item.href ? 
                                    `<p class="text-gray-600"><a href="${item.href}" class="hover:text-primary transition">${item.value}</a></p>` :
                                    `<p class="text-gray-600">${item.value}</p>`
                                }
                            </div>
                        </div>
                    `).join('');
                }

                // Update social media
                if (data.socialMedia) {
                    const socialContainer = infoContainer.querySelector('.mt-8');
                    if (socialContainer) {
                        const label = socialContainer.querySelector('h4');
                        if (label) label.textContent = data.socialMedia.label;

                        const iconsContainer = socialContainer.querySelector('.flex.space-x-4');
                        if (iconsContainer) {
                            iconsContainer.innerHTML = data.socialMedia.items.map(item => `
                                <a href="${item.href}"
                                    class="w-12 h-12 rounded-lg flex items-center justify-center neumorphic-icon"
                                    title="${item.title}">
                                    <i class="${item.icon}"></i>
                                </a>
                            `).join('');
                        }
                    }
                }
            }
        }

        // Update form
        if (data.form) {
            const formContainer = section.querySelector('.bg-surface.p-8');
            if (formContainer) {
                const formTitle = formContainer.querySelector('h3.text-2xl');
                if (formTitle) formTitle.textContent = data.form.title;

                const form = formContainer.querySelector('form');
                if (form && data.form.fields) {
                    form.id = 'contact-form';
                    form.innerHTML = data.form.fields.map(field => {
                        if (field.type === 'textarea') {
                            return `
                                <div class="mb-${field.id === 'message' ? '6' : '4'}">
                                    <label for="${field.id}" class="block text-gray-700 mb-2">${field.label}</label>
                                    <textarea id="${field.id}" name="${field.id}" rows="${field.rows || 4}" ${field.required ? 'required' : ''}
                                        class="w-full px-4 py-3 rounded-lg border border-border bg-surface focus:outline-none focus:ring-2 focus:ring-primary/50 transition-colors"
                                        placeholder="${field.placeholder || ''}"></textarea>
                                </div>
                            `;
                        } else {
                            return `
                                <div class="mb-4">
                                    <label for="${field.id}" class="block text-gray-700 mb-2">${field.label}</label>
                                    <input type="${field.type}" id="${field.id}" name="${field.id}" ${field.required ? 'required' : ''}
                                        class="w-full px-4 py-3 rounded-lg border border-border bg-surface focus:outline-none focus:ring-2 focus:ring-primary/50 transition-colors"
                                        placeholder="${field.placeholder || ''}">
                                </div>
                            `;
                        }
                    }).join('') + `
                        <button type="${data.form.submitButton.type}"
                            class="w-full bg-primary text-white py-3 px-6 rounded-lg hover:bg-primary-dark transition shadow-lg hover:shadow-xl">
                            ${data.form.submitButton.text}
                        </button>
                    `;
                }

                // Re-initialize form handler
                this.initContactForm();
            }
        }
    }

    // Load Footer
    async loadFooter() {
        const data = await this.loadJSON('footer.json');
        if (!data) return;

        const footer = document.querySelector('footer');
        if (!footer) return;

        // Update brand
        const brand = footer.querySelector('a.text-2xl');
        if (brand && data.brand) {
            brand.textContent = data.brand.text;
            brand.href = data.brand.href;
        }

        // Update copyright
        const copyright = footer.querySelector('p.text-gray-400');
        if (copyright) copyright.textContent = data.copyright;

        // Update social media
        const socialContainer = footer.querySelector('.flex.justify-center.space-x-6');
        if (socialContainer && data.socialMedia) {
            socialContainer.innerHTML = data.socialMedia.map(item => `
                <a href="${item.href}"
                    class="w-12 h-12 rounded-lg flex items-center justify-center neumorphic-icon-dark"
                    title="${item.title}">
                    <i class="${item.icon}"></i>
                </a>
            `).join('');
        }
    }

    // Initialize smooth scroll for navigation links
    initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    e.preventDefault();
                    const headerHeight = document.querySelector('nav')?.offsetHeight || 0;
                    const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight - 20;
                    
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });
    }

    // Initialize journey tabs
    initJourneyTabs() {
        const journeyTabs = document.querySelectorAll('.journey-tab');
        const journeyContents = document.querySelectorAll('.journey-content');
        
        if (journeyTabs.length > 0) {
            journeyTabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    const targetTab = this.id;
                    const targetContent = targetTab.replace('tab-', 'content-');
                    
                    journeyTabs.forEach(t => {
                        t.classList.remove('border-primary', 'text-primary', 'font-medium');
                        t.classList.add('border-transparent', 'text-gray-600');
                    });
                    
                    journeyContents.forEach(content => {
                        content.classList.add('hidden');
                    });
                    
                    this.classList.remove('border-transparent', 'text-gray-600');
                    this.classList.add('border-primary', 'text-primary', 'font-medium');
                    
                    const contentElement = document.getElementById(targetContent);
                    if (contentElement) {
                        contentElement.classList.remove('hidden');
                    }
                });
            });
        }
    }

    // Initialize portfolio filter
    initPortfolioFilter() {
        const filterButtons = document.querySelectorAll('.portfolio-filter-btn');
        const portfolioItems = document.querySelectorAll('.portfolio-item');
        
        if (filterButtons.length > 0) {
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    filterButtons.forEach(btn => {
                        btn.classList.remove('bg-primary', 'text-white');
                        btn.classList.add('hover:bg-gray-200');
                    });
                    
                    this.classList.add('bg-primary', 'text-white');
                    this.classList.remove('hover:bg-gray-200');
                    
                    const filterValue = this.getAttribute('data-filter');
                    
                    portfolioItems.forEach(item => {
                        if (filterValue === 'all' || item.getAttribute('data-category') === filterValue) {
                            item.style.display = 'block';
                        } else {
                            item.style.display = 'none';
                        }
                    });
                });
            });
        }
    }

    // Initialize contact form
    initContactForm() {
        const contactForm = document.getElementById('contact-form');
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                const formObject = {};
                formData.forEach((value, key) => {
                    formObject[key] = value;
                });
                
                console.log('Form submitted:', formObject);
                alert('Thank you for your message! I will get back to you soon.');
                this.reset();
            });
        }
    }

    // Load all data dengan loading state
    async loadAll() {
        try {
            console.log('🔄 Starting to load all JSON data...');
            
            // Show loading indicator
            this.showLoadingState(true);
            
            // Load critical sections first (Navigation, Hero, Contact, Footer)
            // These render immediately
            const criticalStart = Date.now();
            await Promise.allSettled([
                this.loadNavigation(),
                this.loadHero(),
                this.loadFooter()
            ]);
            const criticalTime = Date.now() - criticalStart;
            console.log(`✅ Critical sections loaded in ${criticalTime}ms`);
            
            // Hide loading for critical sections
            this.showLoadingState(false);
            
            // Load other sections in parallel (non-blocking)
            const otherStart = Date.now();
            const results = await Promise.allSettled([
                this.loadSkillset(),
                this.loadJourney(),
                this.loadPortfolio(),
                this.loadAchievements(),
                this.loadBlog(),
                this.loadContact()
            ]);
            const otherTime = Date.now() - otherStart;
            console.log(`✅ Other sections loaded in ${otherTime}ms`);
            
            // Check for any failures
            const failures = results.filter(r => r.status === 'rejected');
            if (failures.length > 0) {
                console.warn(`⚠️ ${failures.length} section(s) failed to load`);
                failures.forEach(f => console.error('Failed:', f.reason));
            }
            
            const successCount = results.filter(r => r.status === 'fulfilled').length;
            console.log(`✅ Total: ${successCount + 3}/11 sections loaded successfully!`);
            console.log(`⚡ Total load time: ${criticalTime + otherTime}ms`);
            
            // Show warning if opened via file://
            if (window.location.protocol === 'file:') {
                console.error('❌ ERROR: Website opened via file:// protocol');
                console.error('JSON files cannot be loaded via file:// due to CORS policy');
                console.error('Please use a local web server:');
                console.error('  python3 -m http.server 8000');
                console.error('  Then open: http://localhost:8000');
                
                // Show alert to user
                setTimeout(() => {
                    alert('⚠️ PERINGATAN!\n\nFile JSON tidak bisa di-load jika website dibuka langsung dari file system.\n\nGunakan web server lokal:\npython3 -m http.server 8000\n\nLalu buka: http://localhost:8000');
                }, 1000);
            }
        } catch (error) {
            console.error('❌ Critical error loading data:', error);
            this.showLoadingState(false);
        }
    }

    // Show/hide loading state
    showLoadingState(show) {
        let loadingOverlay = document.getElementById('data-loading-overlay');
        
        if (show) {
            if (!loadingOverlay) {
                loadingOverlay = document.createElement('div');
                loadingOverlay.id = 'data-loading-overlay';
                loadingOverlay.className = 'fixed inset-0 bg-white/50 backdrop-blur-sm flex items-center justify-center z-40 transition-opacity duration-300';
                loadingOverlay.innerHTML = `
                    <div class="bg-white p-8 rounded-2xl shadow-neumorph text-center">
                        <div class="w-12 h-12 border-4 border-gray-200 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
                        <p class="text-gray-600 font-medium">Loading content...</p>
                    </div>
                `;
                document.body.appendChild(loadingOverlay);
            }
            loadingOverlay.style.display = 'flex';
        } else {
            if (loadingOverlay) {
                loadingOverlay.style.display = 'none';
                // Remove after animation
                setTimeout(() => {
                    if (loadingOverlay && loadingOverlay.parentNode) {
                        loadingOverlay.remove();
                    }
                }, 300);
            }
        }
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Initializing Data Loader...');
    const loader = new DataLoader();
    loader.loadAll().then(() => {
        console.log('✅ All data loading completed!');
        // Re-initialize navigation highlighting after data is loaded
        if (typeof highlightNav === 'function') {
            highlightNav();
        }
    }).catch(error => {
        console.error('❌ Failed to load all data:', error);
    });
});

