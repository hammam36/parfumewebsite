#!/bin/bash

# Quick Start Script untuk Optimized Portfolio
# Jalankan: bash setup-optimized.sh

echo "🚀 Setting up Optimized Portfolio..."

# 1. Backup file lama
echo "📦 Backing up original files..."
if [ -f index.html ]; then
    cp index.html index-old-$(date +%Y%m%d-%H%M%S).html
    echo "✅ Original index.html backed up"
fi

# 2. Setup optimized version
echo "🔄 Installing optimized version..."
if [ -f index-optimized.html ]; then
    cp index-optimized.html index.html
    echo "✅ Optimized version installed"
else
    echo "❌ index-optimized.html not found!"
    exit 1
fi

# 3. Verify
echo "🔍 Verifying installation..."
if grep -q "optimized-data-loader.js" index.html; then
    echo "❌ Update script reference first!"
    echo "   Edit index.html, find: <script src=\"js/data-loader.js\"></script>"
    echo "   Replace with: <script src=\"js/optimized-data-loader.js\"></script>"
else
    echo "✅ Script references correct"
fi

# 4. Check data files
echo "📂 Checking data files..."
DATA_FILES=(
    "data/navigation.json"
    "data/hero.json"
    "data/skillset.json"
    "data/journey.json"
    "data/portfolio.json"
    "data/achievements.json"
    "data/blog.json"
    "data/contact.json"
    "data/footer.json"
)

MISSING=0
for file in "${DATA_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        echo "❌ Missing: $file"
        MISSING=$((MISSING+1))
    fi
done

if [ $MISSING -eq 0 ]; then
    echo "✅ All data files present"
else
    echo "⚠️  $MISSING data files missing"
fi

# 5. Ready!
echo ""
echo "✨ Setup complete!"
echo ""
echo "📝 Next steps:"
echo "1. Edit index.html if needed (update script references)"
echo "2. Run local server:"
echo "   python3 -m http.server 8000"
echo "3. Open: http://localhost:8000"
echo ""
echo "📚 For detailed info, see: OPTIMIZATION-GUIDE.md"
