# Data JSON Files untuk Portfolio

Semua data website portfolio disimpan dalam file JSON terpisah untuk memudahkan pengelolaan tanpa perlu mengubah HTML atau JavaScript.

## Struktur File

### 1. `navigation.json`
Menu navigasi website
- `brand`: Brand/logo di navbar
- `menuItems`: Daftar menu item

### 2. `hero.json`
Hero section / Home section
- Informasi pribadi (nama, title, description)
- Social media links (Find With Me)
- Best skills icons
- Profile image
- Floating elements

### 3. `skillset.json`
Skillset & Toolset section
- Section header (tag, title)
- Array cards yang berisi:
  - Icon, title, subtitle, description
  - Tools dengan icon dan warna
  - Daftar keahlian

### 4. `journey.json`
My Journey section (Education & Experience)
- Section header
- Tabs (Education, Experience)
- Education items dengan status (completed, ongoing, planned)
- Experience items dengan icon, tags

### 5. `portfolio.json`
Portfolio projects section
- Section header
- Filter categories
- Array projects dengan:
  - Title, category, image, description, link, tags

### 6. `achievements.json`
Achievements & Certifications section
- Section header
- Achievements array
- Certifications array
- Setiap item memiliki: year, title, organization, description, icon, link

### 7. `blog.json`
Blog section
- Section header
- Posts array dengan:
  - Category, title, description, date, link
  - Image dengan icon dan gradient

### 8. `contact.json`
Contact section
- Section header
- Contact information (location, email, phone)
- Social media links
- Form fields configuration

### 9. `footer.json`
Footer section
- Brand text
- Copyright text
- Social media links

## Cara Menggunakan

1. Edit file JSON sesuai kebutuhan
2. Pastikan format JSON valid (bisa cek dengan validator JSON online)
3. Refresh halaman website - data akan otomatis dimuat

## Tips

- Gunakan editor dengan syntax highlighting untuk JSON (VS Code recommended)
- Selalu tutup tanda kurung dan kurung kurawal dengan benar
- Untuk menambah item baru, copy struktur yang sudah ada dan edit isinya
- Untuk menghapus item, hapus seluruh object dari array
- Icon menggunakan Font Awesome classes (contoh: `fas fa-code`, `fab fa-github`)

